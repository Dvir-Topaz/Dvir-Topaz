package Dvir.BootProj.Web;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale.Category;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Exceptions.CantChangeCouponOrCompanyIdException;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;
import Dvir.BootProj.Exceptions.CompanyExistsException;
import Dvir.BootProj.Exceptions.CouponAlreadyExistsException;
import Dvir.BootProj.Exceptions.CouponDoesntExistException;
import Dvir.BootProj.Services.CompanyFacade;

//A classthat allow the website to access inqueries related company details
@RestController
@RequestMapping("Company")
public class CompanyController {

	@Autowired
	Map<String, Session> sessionsMap;
	
		// A method to add a new coupon to the DB via website
		@PostMapping("/coupons/{token}")
		public ResponseEntity<Object> addNewCoupon(@PathVariable String token, @RequestBody Coupon coupon) throws CouponAlreadyExistsException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				CompanyFacade facade = (CompanyFacade) session.getFacade();
				try {
					facade.addCoupon(coupon);
					return ResponseEntity.ok(coupon);
				} catch (CouponAlreadyExistsException e) {
					return ResponseEntity.badRequest().body(e.getMessage());
				}
			} else {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
			}
		}
		// A method to update a specific coupon's details to the DB, via website
		@PostMapping("/coupons/{token}")
		public ResponseEntity<Object> updateCoupon(@PathVariable String token, @RequestBody Coupon coupon) throws CouponDoesntExistException, CantChangeCouponOrCompanyIdException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				CompanyFacade facade = (CompanyFacade) session.getFacade();
				facade.updateCoupon(coupon);
				return ResponseEntity.ok(coupon);
			} else {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
			}
		}
		
		// A method to delete a coupon from the DB, also delete coupons purchases from the customers DB via website
		@DeleteMapping("/coupons/{token}{couponId}")
		public ResponseEntity<Object> deleteCoupon(@PathVariable String token, @RequestBody int couponId) throws CompanyDoesntExistException, CouponDoesntExistException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				CompanyFacade facade = (CompanyFacade) session.getFacade();
				facade.deleteCoupon(couponId);
				return ResponseEntity.ok(couponId);
			} else {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
			}
		}
		
		// A method to get all the coupons from a specific company from the DB via website
		@GetMapping("/coupons/{token}")
		public List<Coupon> getAllCompanyCoupons(@PathVariable String token) throws CompanyDoesntExistException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				CompanyFacade facade = (CompanyFacade) session.getFacade();
				return facade.getAllCoupons();
			} 
			return new ArrayList<Coupon>(); 
		}
		
//		// A method to get all the coupons from a specific category from the DB via website
//				@GetMapping("/company/coupon/category/{token}")
//				public List<Coupon> CouponsByCategory(@PathVariable String token, @RequestBody Category category) {
//					Session session = sessionsMap.get(token);
//					if(session != null) {
//						CompanyFacade facade = (CompanyFacade) session.getFacade();
//						
//						return facade.getCouponByCategory(category);
//						
//					}
//					return List<Coupon>; 
//				}
				
				// A method to get all the coupons under a specific price from the DB via website
				@GetMapping("/coupons/{token}{maxprice}")
				public List<Coupon> CouponsByPrice(@PathVariable String token, @RequestBody double maxPrice,  @RequestBody List<Coupon> companyCoupons) {
					Session session = sessionsMap.get(token);
					if(session != null) {
						CompanyFacade facade = (CompanyFacade) session.getFacade();
						return facade.getCouponByPrice(maxPrice);
					}
					return new ArrayList<Coupon>(); 
				}
				// A method to ger a specific company details from the DB via website
				@GetMapping("/companies/{token}")
				public Company getCompanyDetails(@PathVariable String token) throws CompanyDoesntExistException {
					Session session = sessionsMap.get(token);
					Company comp = null;
					if(session != null) {
						CompanyFacade facade = (CompanyFacade) session.getFacade();
						try {
							return facade.getCompanyDetails();
						} catch (CompanyDoesntExistException e) {
						}
					}
					return comp;
				}
}
