package Dvir.BootProj.Web;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Locale.Category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Dvir.BootProj.Beans.CategoryType;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.Exceptions.CantChangeCouponOrCompanyIdException;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;
import Dvir.BootProj.Exceptions.CouponAlreadyExistsException;
import Dvir.BootProj.Exceptions.CouponAlreadyPurchaseException;
import Dvir.BootProj.Exceptions.CouponDoesntExistException;
import Dvir.BootProj.Exceptions.CustomerDoesntExistException;
import Dvir.BootProj.Exceptions.ExpiredCouponException;
import Dvir.BootProj.Exceptions.NoCouponsInStockException;
import Dvir.BootProj.Services.CompanyFacade;
import Dvir.BootProj.Services.CustomerFacade;

//A classthat allow the website to access inqueries related company details
@RestController
@RequestMapping("Customer")
public class CustomerController {

	@Autowired
	Map<String, Session> sessionsMap;
	
		// A method to add a new coupon purchase to the customer on the DB via website
		@PostMapping("/customer/coupons/{token}")
		public ResponseEntity<Object> PurchaseCoupon(@PathVariable String token, @RequestBody Coupon coupon) throws CouponAlreadyExistsException, ExpiredCouponException, CouponAlreadyPurchaseException, SQLException, CouponDoesntExistException, CustomerDoesntExistException, NoCouponsInStockException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				CustomerFacade facade = (CustomerFacade) session.getFacade();
				facade.purchaseCoupon(coupon);
				return ResponseEntity.ok(coupon);
			} else {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
			}
		}
		// A method to get allcoupons of a specific customer from the DB, via website
		@GetMapping("/customer/coupons/{token}{customerId}")
		public List<Coupon> getCustomerCoupons(@PathVariable String token, @RequestBody int customerId) throws CustomerDoesntExistException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				CustomerFacade facade = (CustomerFacade) session.getFacade();
				return facade.getAllCustomerCoupons(customerId);
			} 
			return new ArrayList<Coupon>();
		}

		
		// A method to get all the coupons from a specific customer and a specific category from the DB via website
				@GetMapping("/customer/coupons/{token}{category}")
				public List<Coupon> CustomerCouponsByCategory(@PathVariable String token, @RequestBody CategoryType category) {
					Session session = sessionsMap.get(token);
					if(session != null) {
						CustomerFacade facade = (CustomerFacade) session.getFacade();
						return facade.getAllCustomerCouponsFromCategory(category);
					}
					return new ArrayList<Coupon>(); 
				}
				
				// A method to get all the coupons under a specific price from the DB via website
				@GetMapping("/customer/coupons/{token}{maxprice}")
				public List<Coupon> CustomerCouponsByPrice(@PathVariable String token, @RequestBody double maxPrice) {
					Session session = sessionsMap.get(token);
					if(session != null) {
						CustomerFacade facade = (CustomerFacade) session.getFacade();
						return facade.getCouponByPrice(maxPrice);
					}
					return new ArrayList<Coupon>(); 
				}
				// A method to ger a specific company details from the DB via website
				@GetMapping("/customers/{token}")
				public Customer getCustomerDetails(@PathVariable String token) throws CustomerDoesntExistException {
					Customer cust = null;

					Session session = sessionsMap.get(token);
					if(session != null) {
						CustomerFacade facade = (CustomerFacade) session.getFacade();
						return facade.getCustomerDetails();
					}
					return cust;
				}
}
