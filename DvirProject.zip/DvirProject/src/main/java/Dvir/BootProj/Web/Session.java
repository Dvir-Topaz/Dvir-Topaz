package Dvir.BootProj.Web;

import Dvir.BootProj.Services.ClientFacade;

public class Session {
	private ClientFacade facade;
	private long lastAccessed;
	
	
	public Session(ClientFacade facade, long lastAccessed) {
		this.facade = facade;
		this.lastAccessed = lastAccessed;
	}

	public ClientFacade getFacade() {
		return facade;
	}

	public long getLastAccessed() {
		return lastAccessed;
	}
	
	public boolean timeOut() {
		if (System.currentTimeMillis()-Session.this.lastAccessed>1000*60*30) {
			return true;
		}
		return false;
	}
	
	
}
