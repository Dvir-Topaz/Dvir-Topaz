package Dvir.BootProj.Web;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;
import Dvir.BootProj.Exceptions.CompanyExistsException;
import Dvir.BootProj.Exceptions.CustomerAlreadyExistsException;
import Dvir.BootProj.Exceptions.CustomerDoesntExistException;
import Dvir.BootProj.Services.AdminFacade;

@RestController
@RequestMapping("Administrator")
public class AdminController  {

	@Autowired
	Map<String, Session> sessionsMap;
	Calendar cal = Calendar.getInstance();

	
	// A method to check if the admin login is accurate
	public boolean login(String email, String password) {
		if (email.equals("admin@admin.com") && password.equals("admin"))
		return true;
	return false;}
	
	// A method to decalre timeout if the user  wasn't active in the website for the last 30 minutes
	private boolean isTimeout(Session session) {
		if (session.timeOut()==true)
		return true;
		return false;}
	
	// A method to add a new company to the DB via website
	@PostMapping("/companies/{token}")
	public ResponseEntity<Company> addNewCompany(@PathVariable String token, @RequestBody Company company) {
		Session session = sessionsMap.get(token);
		if(session != null) {
			AdminFacade facade = (AdminFacade) session.getFacade();
			try {
				facade.addCompany(company);
				return ResponseEntity.ok(company);
			} catch (CompanyExistsException e) {
			}	}
		return null;
	}
	// A method to update a specific company's details to the DB, via website
	@PutMapping("/companies/{token}")
	public ResponseEntity<Object> updateCompany(@PathVariable String token, @RequestBody Company company) throws CompanyDoesntExistException {
		Session session = sessionsMap.get(token);
		if(session != null) {
			AdminFacade facade = (AdminFacade) session.getFacade();
			try {
				facade.updateCompany(company);
				return ResponseEntity.ok(company);
			} catch (CompanyExistsException e) {
				return ResponseEntity.badRequest().body(e.getMessage());
			}
		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
		}
	}
	// A method to delete a company from DB via website
	@DeleteMapping("/companies/{token}/{companyId}")
	public ResponseEntity<Object> deleteCompany(@PathVariable String token, @RequestBody int companyId) throws CompanyDoesntExistException {
		Session session = sessionsMap.get(token);
		if(session != null) {
			AdminFacade facade = (AdminFacade) session.getFacade();
			facade.deleteCompany(companyId);
			return ResponseEntity.ok(companyId);
		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
		}
	}
	
	// A method to get all the companies from the DB via website
	@GetMapping("/companies/{token}")
	public List<Company> getAllCompanies(@PathVariable String token, @RequestBody Company companies)  {
		Session session = sessionsMap.get(token);
		if(session != null) {
			AdminFacade facade = (AdminFacade) session.getFacade();
			return facade.getAllCompanies();
		}
		return null; 
	}
	
	// A method to get one company from the DB via website using the company's ID
	@GetMapping("/companies/{token}/{companyId}")
	public Company getOneCompany(@PathVariable String token, int companyId) throws CompanyDoesntExistException, SQLException {
		Session session = sessionsMap.get(token);
		if(session != null) {
			AdminFacade facade = (AdminFacade) session.getFacade();
			return facade.getOneCompany(companyId);
		} else {return null;}
	}
	
	// A method to add a new customer to the DB via website
	@PostMapping("/customers/{token}")
	public ResponseEntity<Object> addNewCustomer(@PathVariable String token, @RequestBody Customer customer) throws CustomerAlreadyExistsException {
		Session session = sessionsMap.get(token);
		if(session != null) {
			AdminFacade facade = (AdminFacade) session.getFacade();
			facade.addCustomer(customer);
			return ResponseEntity.ok(customer);
		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
		}
	}
	// A method to update a specific customer's details to the DB, via website
	@PutMapping("/customers/{token}")
	public ResponseEntity<Object> updateCustomer(@PathVariable String token, @RequestBody Customer customer) throws CustomerDoesntExistException, Exception {
		Session session = sessionsMap.get(token);
		if(session != null) {
			AdminFacade facade = (AdminFacade) session.getFacade();
				facade.updateCustomer(customer);
				return ResponseEntity.ok(customer);
		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
		}
	}
	
	// A method to delete a customer from via website
		@DeleteMapping("/customers/{token}/{customerId}")
		public ResponseEntity<Object> deleteCustomer(@PathVariable String token, @RequestBody int customerId) throws CustomerDoesntExistException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				AdminFacade facade = (AdminFacade) session.getFacade();
				facade.deleteCustomer(customerId);
				return ResponseEntity.ok(customerId);
			} else {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized login");
			}
		}
		
		// A method to get all the customers from the DB via website
		@GetMapping("/customers/{token}")
		public List<Customer> getAllCustomers(@PathVariable String token )  {
			Session session = sessionsMap.get(token);
			if(session != null) {
				AdminFacade facade = (AdminFacade) session.getFacade();
				return  facade.getAllCustomers();
			} else {
			}
			return new ArrayList<Customer>(); 
		}
		
		// A method to get one customer from the DB via website using the customer's ID
		@GetMapping("/customers/{token}/{customerId}")
		public Customer getOneCustomer(@PathVariable String token, int customerId) throws CustomerDoesntExistException, SQLException {
			Session session = sessionsMap.get(token);
			if(session != null) {
				AdminFacade facade = (AdminFacade) session.getFacade();
				return facade.getOneCustomer(customerId);
			} else {throw new CustomerDoesntExistException();}
		}
}
