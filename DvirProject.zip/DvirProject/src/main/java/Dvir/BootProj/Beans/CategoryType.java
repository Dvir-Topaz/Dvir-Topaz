package Dvir.BootProj.Beans;

public enum CategoryType {

	Sport, Electronics, Food, resturant, vacation

}
