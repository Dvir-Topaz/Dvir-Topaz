package Dvir.BootProj.DB;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import Dvir.BootProj.Beans.CategoryType;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.Exceptions.CouponDoesntExistException;

@Repository
public class CouponDBDAO {

	@Autowired
	private CouponRepository coupRepo;
	@Autowired
	private CouponRepository customRepo;

	//A method to add a new coupon to the DB
	public void addCoupon(Coupon coupon) {
		coupRepo.save(coupon);
	}
	//A method to add a new purchase of coupon
	public void addCouponPurchase(int customerId, int couponId) throws CouponDoesntExistException {
		if (customRepo.findById(customerId) != null && coupRepo.findById(couponId) != null);{
			coupRepo.addCouponPurchase(customerId, couponId);
		}
		throw new CouponDoesntExistException();
		}
	
	//A method to delete coupon from the DB
	public void deleteCoupon(int couponId) {
		coupRepo.deleteById(couponId);
	}
	
	//A method to update the coupon's data to the DB
	public void updateCoupon(Coupon coupon) {
		if(coupRepo.existsById(coupon.getCouponId()))
			coupRepo.save(coupon);
	}
	
	//A method to get from the DB a coupon by coupon ID
	public Coupon getCouponById(int couponId) {
		Optional<Coupon> opt = coupRepo.findById(couponId);
		if(opt.isPresent())
			return opt.get();
		return null; 
	}
	
	//A method to get get all the coupons registered on the DB
	public List<Coupon> getAllCoupons(){
		return coupRepo.findAll();
	}
	
	//A method to get get all the coupons fro a specific category from the DB
	public Coupon getCouponByCategory(CategoryType category) {
		List<Coupon> opt = coupRepo.findCouponByCategory(category);
		if (opt.contains(category)) {
			return (Coupon) opt;}
		return null; 
	}
	
}
	