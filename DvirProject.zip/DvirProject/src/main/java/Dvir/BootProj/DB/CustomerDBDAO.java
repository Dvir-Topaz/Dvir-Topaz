package Dvir.BootProj.DB;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;

@Repository
public class CustomerDBDAO {

	@Autowired
	private CustomerRepository custRepo;
	
	//A method add a new customer to the DB
	public void addCustomer(Customer customer) {
		custRepo.save(customer);
	}
	
	//A method delete a customer from the DB
	public void deleteCustomer(int customerId) {
		custRepo.deleteById(customerId);
	}
	
	//A method update a customer's data
	public void updateCustomer(Customer customer) {
		if(custRepo.existsById(customer.getCustomerId()))
			custRepo.save(customer);
	}
	
	//A method get a customer's from the DB via customer ID
	public Customer getCustomersById(int customerId) {
		Optional<Customer> opt = custRepo.findById(customerId);
		if(opt.isPresent())
			return opt.get();
		return null; 
	}
	//A method get a list of all the customers from the DB
	public List<Customer> getAllCustomers(){
		return custRepo.findAll();
	}
	
	//A method get a list of all coupons purchased by a specific via customer ID
	public List<Coupon> getAllCustomerCoupons(int customerId){
		return custRepo.findById(customerId).get().getCoupons();
	}
	
	//A method get a customer via his email and password
	public Customer findCustomerByEmailAndPassword(String email, String password) {
		return custRepo.FindCustomerByEmailAndPassword(email, password);
	}

	public boolean login() {
		return false;
	}
}