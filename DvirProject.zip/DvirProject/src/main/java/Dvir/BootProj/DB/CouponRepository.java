package Dvir.BootProj.DB;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import Dvir.BootProj.Beans.CategoryType;
import Dvir.BootProj.Beans.Coupon;

public interface CouponRepository extends JpaRepository<Coupon, Integer> {
	
	//An interface for the coupon DBDAO
 Coupon addCouponPurchase(int customerId, int couponId);
 Coupon deleteCouponPurchase(int customerId, int couponId);
 List<Coupon>findCouponByCategory(CategoryType category);

}