package Dvir.BootProj.DB;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;


//a class to designed to implement requests and orders of the admin related to a company

@Repository
public class CompanyDBDAO {

	@Autowired
	private CompanyRepository compRepo;
	
	//A method to add a new company to the DB
	public void addCompany(Company company) {
		compRepo.save(company);
	}
		//A method to delete an existing company from the DB
	public void deleteCompany(int companyId) {
		compRepo.deleteById(companyId);
	}
	
	//A method to update an existing company's data
	public void updateCompany(Company company) throws CompanyDoesntExistException{
		if(compRepo.existsById(company.getComapnyId()))
			compRepo.save(company);
		throw new CompanyDoesntExistException();
	}
	
	//A method to get on company from the DB via companyID
	public Company getCompanyById(int companyId) throws CompanyDoesntExistException{
		Optional<Company> opt = compRepo.findById(companyId);
		if(opt.isPresent())
			return opt.get();
		throw new CompanyDoesntExistException();
	}
	
	//A method to get all existing companies from the DB
	public List<Company> getAllcompanies(){
		return compRepo.findAll();
	}
	//A method to get  from the DB all the coupons that the company issued
	public List<Coupon> getAllcompanyCoupons(int companyId){
		return compRepo.findAll().get(companyId).getCoupons();
	}
	
	//A method to get on company from the DB via company email and password
	public Company findCompanyByEmailAndPassword(String Email,String Password) {
		return compRepo.findCompanyByEmailAndPassword(Email, Password);
	}

	public boolean login() {
		return false;
	}



}