package Dvir.BootProj.DB;

import org.springframework.data.jpa.repository.JpaRepository;

import Dvir.BootProj.Beans.Company;

public interface CompanyRepository extends JpaRepository<Company, Integer> {

	//An interface for the company DBDAO
 Company findCompanyByEmailAndPassword(String email, String password);

}