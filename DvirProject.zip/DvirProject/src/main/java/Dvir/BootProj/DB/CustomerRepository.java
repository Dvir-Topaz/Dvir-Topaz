package Dvir.BootProj.DB;
import org.springframework.data.jpa.repository.JpaRepository;

import Dvir.BootProj.Beans.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	
	//An interface for the customer DBDAO
 Customer FindCustomerByEmailAndPassword(String email, String password);

}