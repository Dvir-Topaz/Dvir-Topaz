package Dvir.BootProj.DB;

//An Enum to determine all the user types 
public enum ClientType {

	Customer, Company, Administrator;
}