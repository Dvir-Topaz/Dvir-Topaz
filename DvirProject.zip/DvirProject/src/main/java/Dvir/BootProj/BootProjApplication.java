package Dvir.BootProj;

import java.sql.Date;
import java.util.Calendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import Dvir.BootProj.Beans.CategoryType;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.DB.ClientType;
import Dvir.BootProj.Login.LoginManager;
import Dvir.BootProj.Services.AdminFacade;
import Dvir.BootProj.Services.ClientFacade;
import Dvir.BootProj.Services.CompanyFacade;
import Dvir.BootProj.Services.CustomerFacade;


@SpringBootApplication
public class BootProjApplication {

@SuppressWarnings("deprecation")
public static void main(String[] args) throws Exception, Exception {
ConfigurableApplicationContext ctx = SpringApplication.run(BootProjApplication.class, args);

// run the ExpiredCoupon Job
//Runnable run = new ExpiredCouponJob(false, new CouponDBDAO());
//Thread job = new Thread(run);
//job.start();
LoginManager login = ctx.getBean(LoginManager.class);
Calendar cal = Calendar.getInstance();

// verify email and password of admin and then run all methods on adminfacade
try {
AdminFacade facade = (AdminFacade) login.login("admin@admin.com", "admin", ClientType.Administrator);
Company comp1 = new Company("Cola", "c@c.com", "1234");
Company comp2 = new Company("pepsi", "p@p.com", "123");
Company comp3 = new Company("zip", "z@z.com", "zz11");
facade.addCustomer(new Customer("Aliza", "Topaz", "aliza@gmail.com", "aliza"));
facade.addCustomer(new Customer("dvir", "Topaz", "dvt@gmail.com", "dv"));
facade.addCustomer(new Customer("anat", "Topaz", "ante@gmail.com", "ana"));
facade.addCompany(comp1);
facade.addCompany(comp2);
facade.addCompany(comp3);
System.out.println(facade.getAllCompanies());
facade.updateCompany(new Company("Mazda", "Mazda@gmail.com", "maz"));
facade.updateCustomer(new Customer("anat", "Erez", "anaterez@gmail.com", "omer"));
System.out.println(facade.getAllCustomers());
System.out.println(facade.getOneCompany(1));
System.out.println(facade.getOneCustomer(1));
facade.deleteCompany(1);
facade.deleteCustomer(1);

// verify email and password of the admin and then run all methods on
// adminfacade
ClientFacade facade1 = login.login("dvir@gmail.com", "dvir", ClientType.Customer);
CustomerFacade custFacade = (CustomerFacade) facade1;
custFacade.purchaseCoupon(new Coupon(4, "Free food", CategoryType.resturant, "FREE ham,burger",
new Date(2016, 3, 3), new Date(2019, 4, 4), 300, 49, ".."));
System.out.println(custFacade.getAllCustomerCoupons(3));
System.out.println(custFacade.getCouponByPrice(49.9));
System.out.println(custFacade.getAllCustomerCouponsFromCategory(CategoryType.vacation));
System.out.println(custFacade.getCustomerDetails());


// verify email and password of company and then run all methods on
// companyfacade
System.out.println("Start of facade Company");
ClientFacade facade2 = login.login("bmw@gmail.com", "bbmmww", ClientType.Company);
System.out.println(facade2);
CompanyFacade compFacade = (CompanyFacade) facade2;
compFacade.addCoupon(new Coupon(3, "Free dish", CategoryType.vacation, "cheap dish waher", new Date(2018, 6,7), new Date(2019, 7, 6), 60, 950.0, ".."));
System.out.println(compFacade.getCompanyDetails());
compFacade.getCouponByPrice(19.9);
compFacade.deleteCoupon(1008);
System.out.println(compFacade.getAllCoupons());

} finally {
//job.stop();
}
}
}


       
