package Dvir.BootProj.Login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import Dvir.BootProj.DB.ClientType;
import Dvir.BootProj.Exceptions.InvalidClientTypeException;
import Dvir.BootProj.Exceptions.LoginFailedException;
import Dvir.BootProj.Services.AdminFacade;
import Dvir.BootProj.Services.ClientFacade;
import Dvir.BootProj.Services.CompanyFacade;
import Dvir.BootProj.Services.CustomerFacade;

@Component
public class LoginManager {

    @Autowired
    private ConfigurableApplicationContext ctx;
     
    @Autowired
    private AdminFacade administrator;
     
    @Autowired
    private CompanyFacade compFacade;
   
    @Autowired
    private CustomerFacade custFacade;
   
    public LoginManager() {
super();
}

    public ClientFacade login(String email, String password, ClientType type) throws InvalidClientTypeException, LoginFailedException {
        switch(type) {
        case Administrator:
            if(administrator.login(email, password))
                return administrator;
            else
                throw new LoginFailedException();
        case Company:
            if(compFacade.login(email, password))
                return compFacade;
            else
                throw new LoginFailedException();          
        case Customer:
            if(custFacade.login(email, password))
                return custFacade;
            else
                throw new LoginFailedException();          
        default:
            throw new InvalidClientTypeException();
        }
    }
   
}
