package Dvir.BootProj.Exceptions;

public class CouponAlreadyPurchaseException extends Exception{

	public CouponAlreadyPurchaseException() {
	super(" Coupon already purchased !! ");
	}
	
}