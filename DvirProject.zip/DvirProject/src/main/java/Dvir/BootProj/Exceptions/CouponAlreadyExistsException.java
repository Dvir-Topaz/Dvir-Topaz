package Dvir.BootProj.Exceptions;

public class CouponAlreadyExistsException extends Exception{

	public CouponAlreadyExistsException() {
	super(" Coupon already exists !! ");
	}
	
}