package Dvir.BootProj.Exceptions;

public class CompanyExistsException extends Exception{

	public CompanyExistsException() {
	super(" Company already exists !! ");
	}
	
}