package Dvir.BootProj.Exceptions;

public class CustomerDoesntExistException extends Exception {

	public CustomerDoesntExistException() {
		super(" Customer doesn't exists !! ");
		}
		
}
