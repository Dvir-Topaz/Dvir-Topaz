package Dvir.BootProj.Exceptions;

public class LoginFailedException extends Exception{

	public LoginFailedException() {
	super(" Login failed !! ");
	}
	
}