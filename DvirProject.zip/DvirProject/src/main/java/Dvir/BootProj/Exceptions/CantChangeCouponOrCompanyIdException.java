package Dvir.BootProj.Exceptions;

public class CantChangeCouponOrCompanyIdException extends Exception {

	public CantChangeCouponOrCompanyIdException() {
		super(" You can't change company ID or copon ID  !! ");
		}
		
}