package Dvir.BootProj.Exceptions;

public class CompanyDoesntExistException extends Exception{

	public CompanyDoesntExistException() {
	super(" Company doesn't exists !! ");
	}
	
}