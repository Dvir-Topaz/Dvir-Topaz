package Dvir.BootProj.Exceptions;

public class CouponDoesntExistException extends Exception {

	public CouponDoesntExistException() {
		super(" Coupon doesn't exists !! ");
		}
		
}
