package Dvir.BootProj.Exceptions;

public class ExpiredCouponException extends Exception {

	public ExpiredCouponException() {
		super(" Coupon has expired !! ");
		}
		
}
