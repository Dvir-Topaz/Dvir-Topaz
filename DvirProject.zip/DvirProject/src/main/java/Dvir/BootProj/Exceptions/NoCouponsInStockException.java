package Dvir.BootProj.Exceptions;

public class NoCouponsInStockException extends Exception{

	public NoCouponsInStockException() {
	super(" There are no more coupons left in stock !! ");
	}
	
}