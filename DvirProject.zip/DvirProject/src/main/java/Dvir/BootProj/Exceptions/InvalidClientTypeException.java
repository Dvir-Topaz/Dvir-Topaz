package Dvir.BootProj.Exceptions;

public class InvalidClientTypeException extends Exception{

	public InvalidClientTypeException() {
	super(" Invalid client !! ");
	}
	
}