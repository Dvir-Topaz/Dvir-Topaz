package Dvir.BootProj.Services;

import java.util.Calendar;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.DB.CompanyDBDAO;
import Dvir.BootProj.DB.CouponDBDAO;
import Dvir.BootProj.DB.CustomerDBDAO;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;

public class ExpiredCouponJob implements Runnable {

	// A class that runs every 24 hours and deletes all expired coupon existing on
	// the DB
	public static int SLEEP_TIME = 1000 * 60 * 60 * 24;
	private boolean quit;
	@Autowired
	private CouponDBDAO coupDB;
	@Autowired
	private CompanyDBDAO compDB;
	@Autowired
	private CustomerDBDAO custDB;

	private int couopnId;

	public ExpiredCouponJob(boolean quit, CouponDBDAO coupDB) {
	this.quit = quit;
	this.coupDB = coupDB;
	}

	public void run() {
	while (!quit) {
	Calendar cal = Calendar.getInstance();
	List<Coupon> allCoupons = coupDB.getAllCoupons();
	for (Coupon c : allCoupons) {
	if (c.getEndDate().before(cal.getTime())) {
	Coupon overdueCoupon = coupDB.getCouponById(c.getCouponId());
	List<Company> companies = compDB.getAllcompanies();
	for (Company comp : companies) {
	overdueCoupon.getCompany().getCoupons().remove(overdueCoupon);
	try {
		compDB.updateCompany(comp);
	} catch (CompanyDoesntExistException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	List<Customer> customers = custDB.getAllCustomers();
	for (Customer cust : customers) {
	if (cust.getCoupons().contains(overdueCoupon)) {
	cust.getCoupons().remove(overdueCoupon);
	custDB.updateCustomer(cust);
	}
	}
	}
	}
	}
	}

	public void StopJob() {
	quit = true;
	}
	}

