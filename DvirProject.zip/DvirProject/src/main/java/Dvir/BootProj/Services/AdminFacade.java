package Dvir.BootProj.Services;

import java.sql.SQLException;
import java.util.List;
import org.springframework.stereotype.Service;

import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;
import Dvir.BootProj.Exceptions.CompanyExistsException;
import Dvir.BootProj.Exceptions.CustomerAlreadyExistsException;
import Dvir.BootProj.Exceptions.CustomerDoesntExistException;


@Service
public class AdminFacade extends ClientFacade {

@Override
public boolean login(String email, String password) {
if(email.equals("admin@admin.com") && password.equals("admin")) {
return true;
}
return false;
}

// Company methods

//A method to check if there is already similar email or password before registering a new company
public void addCompany(Company company) throws CompanyExistsException {
List<Company> allComps = compDB.getAllcompanies();
for (Company comps : allComps) {
if(comps.getEmail().equals(company.getEmail()) || comps.getName().equals(company.getName()))
throw new CompanyExistsException();
}
compDB.addCompany(company);
}

//A method to check if there is already similar company ID or company name  before updating the data of an existing company
    public void updateCompany(Company company) throws CompanyExistsException, CompanyDoesntExistException {
List<Company> allCompanies = compDB.getAllcompanies();
for (Company companies : allCompanies) {
if(companies.getName().contentEquals(company.getName())) {
throw new CompanyExistsException();
}
compDB.updateCompany(company);}
}

  //A method to delete already all coupons from the DB before deleting a the company that  
     public void deleteCompany(int companyId) throws CompanyDoesntExistException {
     Company company = compDB.getCompanyById(companyId);
List<Coupon> allCompanyCoupons = company.getCoupons();
for (Coupon coups : allCompanyCoupons) {
List<Customer> customers = custDB.getAllCustomers();
for (Customer custs : customers) {
custs.getCoupons().remove(coups);
custDB.updateCustomer(custs);
}
company.getCoupons().clear();
compDB.updateCompany(company);
compDB.deleteCompany(companyId);
}
 }

        //A method to get a list of all the registered companies
        public List<Company> getAllCompanies()   {
return compDB.getAllcompanies();}
       
        //A method to get a specific company
        public Company getOneCompany(int companyId) throws SQLException, CompanyDoesntExistException  {
        return compDB.getCompanyById(companyId);
        }
       

        // Customer methods
       
        //A method to check if a customer  already exists in the DB before adding a new customer to the DB
        public void addCustomer(Customer customer) throws CustomerAlreadyExistsException {
        List<Customer> allCusts = custDB.getAllCustomers();
        for (Customer custs : allCusts) {
        if(custs.getEmail().equals(customer.getEmail()))
        throw new CustomerAlreadyExistsException();
        }
        custDB.addCustomer(customer);
        }
       
       
        //A method to check if a customer  exists in the DB before updating his data to the DB
            public void updateCustomer(Customer customer) throws CustomerAlreadyExistsException {
           
            custDB.updateCustomer(customer);
            }
           
            //A method to delete a all couopn purchased by a customer before deleting the coupon from the DB
            public void deleteCustomer(int customerId) throws CustomerDoesntExistException {
            Customer customer = custDB.getCustomersById(customerId);
            customer.getCoupons().clear();
            custDB.updateCustomer(customer);
            custDB.deleteCustomer(customerId);}
           
            //A method to get a list of all the customers registered on  the DB
                    public List<Customer> getAllCustomers()   {
            return custDB.getAllCustomers();}
                   
                   
                    //A method to get a specific customer from  the DB
                    public Customer getOneCustomer(int customerId) throws SQLException, CustomerDoesntExistException  {
                        return custDB.getCustomersById(customerId);
                        }
                       
}

