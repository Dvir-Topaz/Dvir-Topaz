package Dvir.BootProj.Services;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import Dvir.BootProj.Beans.CategoryType;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.Exceptions.CantChangeCouponOrCompanyIdException;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;
import Dvir.BootProj.Exceptions.CouponAlreadyExistsException;
import Dvir.BootProj.Exceptions.CouponAlreadyPurchaseException;
import Dvir.BootProj.Exceptions.CouponDoesntExistException;
import Dvir.BootProj.Exceptions.CustomerDoesntExistException;
import Dvir.BootProj.Exceptions.ExpiredCouponException;
import Dvir.BootProj.Exceptions.NoCouponsInStockException;



@Service
@Scope("prototype")
public class CustomerFacade extends ClientFacade {

private int customerId;

@Override
public boolean login(String email, String password) {
Customer temp = custDB.findCustomerByEmailAndPassword(email, password);
if(temp != null) {
customerId = temp.getCustomerId();
return true;
}
return false;
}

//A method to check if a customer can buy a new coupon
public void purchaseCoupon(Coupon coupon) throws ExpiredCouponException, CouponAlreadyPurchaseException, SQLException, CouponDoesntExistException, CustomerDoesntExistException, NoCouponsInStockException  {
if(coupon.getEndDate().before( new Date(Calendar.getInstance().getTimeInMillis()))){
throw new ExpiredCouponException();
}

// A method to check if there are any coupons remaining in stock
if(coupon.getAmount() == 0) {
throw new NoCouponsInStockException();
}

// A method to check if a customer already purchased a coupon
for (Coupon c : custDB.getCustomersById(customerId).getCoupons()) {
if (c.getCouponId()==coupon.getCouponId()) {
throw new CouponAlreadyPurchaseException();
}
}

// everything is ok! buy the coupon, discount 1 from the coupon stock and update the coupon DB
coupDB.addCoupon(coupon);
coupon.setAmount(-1);
coupDB.updateCoupon(coupon);
Customer cust = getCustomerDetails();
cust.getCoupons().add(coupon);
custDB.updateCustomer(cust);
}

//A method to return a specific company by the CompanyId
public Customer getOneCustomer(int customerId) throws CustomerDoesntExistException {
return custDB.getCustomersById(customerId);}

// A method to return all coupons purchased by a specific customer
public List<Coupon> getAllCustomerCoupons(int customerId)   {
if (custDB.login()==true) {
return custDB.getAllCustomerCoupons(customerId);}
return null;
  }

//A method to delete  all coupons purchased by a specific customer
public void deleteCouponPurchase(Coupon coupon)  {
	Customer cust = getCustomerDetails();
	cust.getCoupons().remove(coupon);
	custDB.updateCustomer(cust);
}


// A method to return all coupons purchased by a specific category
public List<Coupon> getAllCustomerCouponsFromCategory(CategoryType category)   {
List<Coupon> customerCouponsFromCategory=new ArrayList<Coupon>();
  for (Coupon coupon : customerCouponsFromCategory) {
  if (coupon.getCategory().equals(category)) {
  customerCouponsFromCategory.add(coupon);
  }
  }
  return customerCouponsFromCategory;
  }


// A method to return all coupons under a certain price purchased by the logged-on customer
public List<Coupon> getCouponByPrice(double maxPrice)   {
List<Coupon> customerCouponsByPrice=new ArrayList<Coupon>();
for (Coupon coupon : customerCouponsByPrice) {
if (coupon.getPrice()<(maxPrice)) {
customerCouponsByPrice.add(coupon);
}
}
return customerCouponsByPrice;
}


//A method that returns the detailes of the logged-in customer
public Customer getCustomerDetails()  {
   Customer CustomerDetails =custDB.getCustomersById(customerId);
return CustomerDetails;
}
}

