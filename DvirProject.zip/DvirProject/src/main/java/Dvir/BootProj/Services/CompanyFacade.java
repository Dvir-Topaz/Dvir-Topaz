package Dvir.BootProj.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale.Category;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import Dvir.BootProj.Beans.CategoryType;
import Dvir.BootProj.Beans.Company;
import Dvir.BootProj.Beans.Coupon;
import Dvir.BootProj.Beans.Customer;
import Dvir.BootProj.DB.CompanyDBDAO;
import Dvir.BootProj.DB.CouponDBDAO;
import Dvir.BootProj.DB.CustomerDBDAO;
import Dvir.BootProj.Exceptions.CantChangeCouponOrCompanyIdException;
import Dvir.BootProj.Exceptions.CompanyDoesntExistException;
import Dvir.BootProj.Exceptions.CouponAlreadyExistsException;
import Dvir.BootProj.Exceptions.CouponDoesntExistException;
import Dvir.BootProj.Exceptions.CustomerAlreadyExistsException;
import Dvir.BootProj.Exceptions.CustomerDoesntExistException;


@Service
@Scope("prototype")
public class CompanyFacade extends ClientFacade {

private int companyId;

@Override
public boolean login(String email, String password) {
Company temp = compDB.findCompanyByEmailAndPassword(email, password);
if (temp != null) {
companyId = temp.getComapnyId();
return true;
}
return false;
}

// Coupon methods:

// A method to add a new coupon after checking if the coupon's title and ID
// doesnt already exists in the DB
public void addCoupon(Coupon coupon) throws CouponAlreadyExistsException {
List<Coupon> allCoups = coupDB.getAllCoupons();
for (Coupon coups : allCoups) {
if (coups.getTitle().equals(coupon.getTitle()) && coups.getCouponId() == (coupon.getCouponId())) {
throw new CouponAlreadyExistsException();
}
coupDB.addCoupon(coupon);
}
}

// A method to update a specific coupon except changing it's coupon ID or
// company ID
public void updateCoupon(Coupon coupon) throws CantChangeCouponOrCompanyIdException {
List<Coupon> allcoups = coupDB.getAllCoupons();
for (Coupon coupons : allcoups) {
if (coupons.getTitle().equals(coupon.getTitle())) {
throw new CantChangeCouponOrCompanyIdException();
}
coupDB.updateCoupon(coupon);
}
}

// A method to delete a specific coupon
public void deleteCoupon(int couponId) throws CouponDoesntExistException, CompanyDoesntExistException {
Coupon couponToBeDeleted = coupDB.getCouponById(couponId);
Company company = couponToBeDeleted.getCompany();
company.removeCoupon(couponToBeDeleted);
compDB.updateCompany(company);
List<Customer> customers = custDB.getAllCustomers();
for (Customer cust : customers) {
if (cust.getCoupons().contains(couponToBeDeleted)) {
cust.getCoupons().remove(couponToBeDeleted);
custDB.updateCustomer(cust);
}
}
coupDB.deleteCoupon(couponId);
}

// A method to return all coupons of a specific company by the logged-on Company
public List<Coupon> getAllCoupons() {
List<Coupon> allCoupons = coupDB.getAllCoupons();
List<Coupon> allCompanyCoupons = new ArrayList<Coupon>();
for (Coupon coup : allCoupons) {
if (coup.getCompany().getComapnyId() == companyId)
allCompanyCoupons.add(coup);

}
return allCompanyCoupons;
}

//A method to return a specific company by the CompanyId
public Company getOneCompany(int companyId) throws CompanyDoesntExistException {
return compDB.getCompanyById(companyId);}

// A method to return all coupons purchased from a scpecific category
public List<Coupon> getCouponByCategory(Category category) {
List<Coupon> allCouponsByCategory = new ArrayList<Coupon>();
List<Coupon> allCoupons = getAllCoupons();
for (Coupon coups : allCoupons) {
if (coups.getCategory().equals(category)) {
allCouponsByCategory.add(coups);
}
}

return allCouponsByCategory;
}

// A method to return all coupons purchased under a certain price
public List<Coupon> getCouponByPrice(double maxPrice) {
List<Coupon> allCouponsByPrice = new ArrayList<Coupon>();
List<Coupon> allCoupons = getAllCoupons();
for (Coupon coups : allCoupons) {
if (coups.getPrice()<(maxPrice)) {
allCouponsByPrice.add(coups);
}
}

return allCouponsByPrice;
}


// A method that returns the detailes of the company that logged-in
public Company getCompanyDetails() throws CompanyDoesntExistException {
Company CompanyDetails = compDB.getCompanyById(companyId);
return CompanyDetails;
}

public void getAllCompanyCoupons() {
	// TODO Auto-generated method stub
	
}



}

