package Dvir.BootProj.Services;

import org.springframework.beans.factory.annotation.Autowired;
import Dvir.BootProj.DB.CompanyDBDAO;
import Dvir.BootProj.DB.CouponDBDAO;
import Dvir.BootProj.DB.CustomerDBDAO;

//An abstract class for all the services
public abstract class ClientFacade {

	@Autowired
	protected CompanyDBDAO compDB;
	
	@Autowired
	protected CouponDBDAO coupDB;
	
	@Autowired
	protected CustomerDBDAO custDB;

	public abstract boolean login(String email, String password);
	}