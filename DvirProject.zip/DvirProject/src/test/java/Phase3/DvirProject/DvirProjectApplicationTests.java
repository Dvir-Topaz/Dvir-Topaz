package Phase3.DvirProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DvirProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
